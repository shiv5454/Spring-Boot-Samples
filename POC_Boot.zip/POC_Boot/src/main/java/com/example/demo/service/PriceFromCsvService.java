package com.example.demo.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchEvent.Kind;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.example.demo.common.PriceUtility;
import com.example.demo.model.PriceModel;

@Service
public class PriceFromCsvService {
	

	
	@Value("${source.path}")
	private String sourcePath;
	@Value("${backup.path}")
	private String backupPath;
	
	public void test() throws Exception {
		System.out.println(sourcePath);
		System.out.println(backupPath);
		
		Path path = Paths.get(sourcePath);
		
		try {
            Boolean isFolder = (Boolean) Files.getAttribute(path, "basic:isDirectory");
            if (!isFolder) {
                throw new IllegalArgumentException("Path: " + path
                        + " is not a folder");
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

        System.out.println("Watching path: " + path);
		FileSystem fs = path.getFileSystem();

		
		try (WatchService service = fs.newWatchService()) {
			WatchKey key = null;
			path.register(service, StandardWatchEventKinds.ENTRY_CREATE);

			while ((key = service.take()) != null) {
				Kind<?> kind = null;
	            for (WatchEvent<?> watchEvent : key.pollEvents()) {
	            	kind = watchEvent.kind();
	            	//if (StandardWatchEventKinds.ENTRY_CREATE == kind) {
	            	System.out.println(
	                  "Event kind:" + watchEvent.kind() 
	                    + ". File affected: " + watchEvent.context() + ".");

	            	List<PriceModel> read = PriceUtility.read(PriceModel.class, Paths.get(path+"//"+watchEvent.context()));
	            	
	            	read.stream().forEach(System.out::println);
	            	
	            	//}
	            }
	            key.reset();
	        }
		}

        catch (IOException ioe) {
            ioe.printStackTrace();
        } catch (InterruptedException ie) {
            ie.printStackTrace();
        
		}
	}


}
