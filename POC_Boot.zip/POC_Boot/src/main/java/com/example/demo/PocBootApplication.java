package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.example.demo.service.PriceFromCsvService;

@SpringBootApplication
public class PocBootApplication implements CommandLineRunner  {

	@Autowired 
	private PriceFromCsvService priceService;
	
	public static void main(String[] args) {
		SpringApplication  app = new SpringApplication(PocBootApplication.class);
		app.run(args);
		
	}

	@Override
	public void run(String... args) throws Exception {
	
		priceService.test();
	        	
	}

}
