package com.example.demo.common;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import com.example.demo.model.PriceModel;
import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;



public class PriceUtility {

//	private static final CsvMapper mapper = new CsvMapper();
//    public static <T> List<T> read(Class<T> clazz, InputStream stream) throws IOException {
//        CsvSchema schema = mapper.schemaFor(clazz).withHeader().withColumnReordering(true);
//        ObjectReader reader = mapper.readerFor(clazz).with(schema);
//        return reader.<T>readValues(stream).readAll();
//    }
	
//	public static <T> List<T> read(Class<T> clazz, InputStream stream) throws IOException {
//        CsvSchema schema = mapper.schemaFor(clazz).withHeader().withColumnReordering(true);
//        ObjectReader reader = mapper.readerFor(clazz).with(schema);
//        return reader.<T>readValues(stream).readAll();
//    }
	@SuppressWarnings("unchecked")
	public static <T> List<PriceModel> read(Class<T> clazz, Path path) throws Exception {
		System.out.println("Watching path: " + path);
	     //CsvTransfer csvTransfer = new CsvTransfer();
	     @SuppressWarnings("rawtypes")
		ColumnPositionMappingStrategy startegy = new ColumnPositionMappingStrategy();
	     startegy.setType(clazz);
	 
	     Reader reader = Files.newBufferedReader(path);
	     
		CsvToBean cb = new CsvToBeanBuilder(reader)
	       .withType(clazz)
	       .withMappingStrategy(startegy)
	       .build();
	 
	   //csvTransfer.setCsvList(cb.parse());
	   // reader.close();
	    return cb.parse();
	}
}
