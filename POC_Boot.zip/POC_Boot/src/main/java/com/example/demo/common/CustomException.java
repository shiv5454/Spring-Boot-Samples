package com.example.demo.common;

public class CustomException {

}
