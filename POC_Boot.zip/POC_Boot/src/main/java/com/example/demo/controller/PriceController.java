package com.example.demo.controller;

import org.springframework.stereotype.Controller;


@Controller
public class PriceController {
	
	

}
