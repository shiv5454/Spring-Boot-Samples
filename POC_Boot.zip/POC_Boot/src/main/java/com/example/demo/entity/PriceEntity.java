package com.example.demo.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table
public class PriceEntity {

	@Id
//	@NotEmpty
	private String ProductId;
	private String PriceType;
	private Integer Indicator;
	private String CurrencyCode;
	private Double Value;
	@Temporal(TemporalType.TIMESTAMP)
	private Date ValidFrom;
	@Temporal(TemporalType.TIMESTAMP)
	private Date ValidTo;
	
	public String getProductId() {
		return ProductId;
	}
	public void setProductId(String productId) {
		ProductId = productId;
	}
	public String getPriceType() {
		return PriceType;
	}
	public void setPriceType(String priceType) {
		PriceType = priceType;
	}
	public Integer getIndicator() {
		return Indicator;
	}
	public void setIndicator(Integer indicator) {
		Indicator = indicator;
	}
	public String getCurrencyCode() {
		return CurrencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		CurrencyCode = currencyCode;
	}
	public Double getValue() {
		return Value;
	}
	public void setValue(Double value) {
		Value = value;
	}
	public Date getValidFrom() {
		return ValidFrom;
	}
	public void setValidFrom(Date validFrom) {
		ValidFrom = validFrom;
	}
	public Date getValidTo() {
		return ValidTo;
	}
	public void setValidTo(Date validTo) {
		ValidTo = validTo;
	}
	@Override
	public String toString() {
		return "Price [ProductId=" + ProductId + ", PriceType=" + PriceType + ", Indicator=" + Indicator
				+ ", CurrencyCode=" + CurrencyCode + ", Value=" + Value + ", ValidFrom=" + ValidFrom + ", ValidTo="
				+ ValidTo + "]";
	}
	
}
