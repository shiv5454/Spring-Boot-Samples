package com.example.demo.model;

import java.util.Date;

import com.example.demo.common.LocalDateConverter;
import com.example.demo.entity.PriceEntity;
import com.opencsv.bean.CsvBindByPosition;
import com.opencsv.bean.CsvCustomBindByPosition;

//@JsonIgnoreProperties(ignoreUnknown = true)
public class PriceModel {
	@CsvBindByPosition(position = 0, required = true)
	private String ProductId;
	@CsvBindByPosition(position = 1, required = true)
	private String PriceType;
	@CsvBindByPosition(position = 2, required = true)
	private int Indicator;
	@CsvBindByPosition(position = 3, required = true)
	private String CurrencyCode;
	@CsvBindByPosition(position = 4, required = true)
	private double Value;
	@CsvCustomBindByPosition(position = 5, converter = LocalDateConverter.class, required = true)
	private Date ValidFrom;
	@CsvCustomBindByPosition(position = 6, converter = LocalDateConverter.class, required = true)
	private Date ValidTo;
	
	public String getProductId() {
		return ProductId;
	}
	public void setProductId(String productId) {
		ProductId = productId;
	}
	public String getPriceType() {
		return PriceType;
	}
	public void setPriceType(String priceType) {
		PriceType = priceType;
	}
	public int getIndicator() {
		return Indicator;
	}
	public void setIndicator(int indicator) {
		Indicator = indicator;
	}
	public String getCurrencyCode() {
		return CurrencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		CurrencyCode = currencyCode;
	}
	public double getValue() {
		return Value;
	}
	public void setValue(double value) {
		Value = value;
	}
	public Date getValidFrom() {
		return ValidFrom;
	}
	public void setValidFrom(Date validFrom) {
		ValidFrom = validFrom;
	}
	public Date getValidTo() {
		return ValidTo;
	}
	public void setValidTo(Date validTo) {
		ValidTo = validTo;
	}
	
	public PriceEntity getEntity(PriceModel model) {
		PriceEntity entity = new PriceEntity();
		entity.setProductId(model.getProductId());
		entity.setIndicator(model.getIndicator());
		entity.setCurrencyCode(model.getCurrencyCode());
		entity.setPriceType(model.getPriceType());
		entity.setValidFrom(model.getValidFrom());
		entity.setValidTo(model.getValidTo());
		entity.setValue(model.getValue());
		return entity;
	}
	
	public static PriceModel getModel(PriceEntity entity){
		PriceModel model = new PriceModel();
		model.setProductId(entity.getProductId());
		model.setIndicator(entity.getIndicator());
		model.setCurrencyCode(entity.getCurrencyCode());
		model.setPriceType(entity.getPriceType());
		model.setValidFrom(entity.getValidFrom());
		model.setValidTo(entity.getValidTo());
		model.setValue(entity.getValue());
		return model;
	}
	
	@Override
	public String toString() {
		return "Price [ProductId=" + ProductId + ", PriceType=" + PriceType + ", Indicator=" + Indicator
				+ ", CurrencyCode=" + CurrencyCode + ", Value=" + Value + ", ValidFrom=" + ValidFrom + ", ValidTo="
				+ ValidTo + "]";
	}
	
	
	
	
}
